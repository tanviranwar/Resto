<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package resto
 */

?>

	</div><!-- #content -->

	<footer>
		<div class="wrapper">
			 <ul>
      <li>Address</li>
      <li>222/C, Khilgaon</li>
      <li>Dhaka-1219</li>
      <li>Bangladesh</li>
    </ul>

    <ul>
      <li>Contact</li>
      <li>tanvir721@gmail.com</li>
      <li>+880 1683172589</li>
      <li>http://www.pro.com</li>
    </ul>
    <ul>
      <li><a href="#">Blog</a></li>
      <li><a href="#">Careers</a></li>
      <li><a href="#">Privacy</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
    <ul>
      <li><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/logo.png" alt=""></li>
      <li>&copy; All Rights Researved</li>
    </ul>
    <?php dynamic_sidebar ('footer'); ?>
		</div><!-- .wrapper -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
